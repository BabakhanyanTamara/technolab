function sort(items) {
  for(i = 0; i< items.length -1;i++){
      let minindex = i;
    for(let j = i + 1 ; j < items.length; j++){
        if (items[j] < items[minindex]){
        minindex = j;
    } 
}
    let temp = items[i];
    items[i] = items[i + 1 + minIndex ];
    items[minIndex] = temp;

        /*  let reaminingItems = items.slice(i+1)
        let minRemainingindex = minindex(reaminingItems);
        if(reaminingItems[minRemainingindex]< items[i]){
            let temp =items[i];
            items[i] = items[i + 1 + minRemaningindex ];
            items[i +1 minReminingindex] = temp;


        }*/

    }
}
function min(items) {
    if(items.length === 0 ){
        return -1;
    }
    let minindex = 0;
    for(let i = 0; i<items.length;i++){
        if (items[i] < items[minindex]){
        minindex = i
    }

    }
    return minindex
}


// console.log(minindex[])