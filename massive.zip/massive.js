let matrix = [[0,1,2],[4,8,16],[3,9,18]];
/*console.log(matrix[0]);
for(let i = 0; i < matrix.length ; i++) {
    console.log(matrix[i][i]);
}*/
let a = 0; 
for (let i = 0;i < matrix.length; i++){
    for( j = i; j < matrix.length;j++){
        //console.log(matrix[i][j]);
        a = a + matrix[i][j];

       
    }
}
console.log(a);


